#ifdef _WIN32
#include <windows.h>
#include <commctrl.h>
#include <gdiplus.h>
#include <filesystem>
#include <algorithm>
#include <string>
#include <vector>
#include <sstream>
#include <cstdio>
#include <cstring>
#include <iomanip>
#include <cmath>
#include <stdexcept>
#include "Game.hpp"
#include "PlayerSearch.hpp"
#include "CareerStorage.hpp"

namespace {
void trace(const char* message) noexcept {
    HANDLE file=CreateFileA("fu_startup.log",FILE_APPEND_DATA,FILE_SHARE_READ|FILE_SHARE_WRITE,
        nullptr,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);
    if(file!=INVALID_HANDLE_VALUE){
        DWORD written=0;
        WriteFile(file,message,DWORD(std::strlen(message)),&written,nullptr);
        WriteFile(file,"\r\n",2,&written,nullptr);
        CloseHandle(file);
    }
}
LONG WINAPI crashLog(EXCEPTION_POINTERS* info) {
    char msg[256]{};
    sprintf_s(msg,"FATAL exception: 0x%08lx at address %p",
        info->ExceptionRecord->ExceptionCode,info->ExceptionRecord->ExceptionAddress);
    trace(msg);
    return EXCEPTION_CONTINUE_SEARCH;
}
fu::Game& game() {
    // Construct only after program startup; avoids cross-translation-unit init order issues.
    static fu::Game instance;
    return instance;
}
HINSTANCE appInstance{};
HWND mainWindow{}, mainText{}, listControl{}, inputControl{}, titleText{}, subtitleText{}, statusText{}, pitchWindow{}, clubLogoWindow{};
constexpr int NAV_COUNT=19;
constexpr int PREPARATION_PAGE=16;
constexpr int WORLD_MARKET_PAGE=17, SAVES_PAGE=18;
HWND nav[NAV_COUNT]{}, actions[6]{};
HWND setupName{}, setupClub{}, setupRole{}, setupDifficulty{}, setupLeagues{}, setupHelp{}, setupStart{}, setupLoad{};
HWND searchName{},searchPosition{},searchAge{},searchPrice{},searchSort{},searchApply{},searchReset{},searchCount{};
HWND searchLabels[5]{};
fu::PlayerSearchFilter marketFilter;
HFONT uiFont{}, titleFont{}, monoFont{}, smallFont{};
HBRUSH backgroundBrush{}, surfaceBrush{}, inputBrush{};
ULONG_PTR gdiplusToken{};
constexpr COLORREF background=RGB(13,21,35),surface=RGB(23,35,54),primary=RGB(57,112,221),accent=RGB(67,202,179),white=RGB(233,239,247),muted=RGB(160,174,196);
int page=-1;
bool started=false, showPitch=true, shortlistOnly=false;
bool autoPlayMatch=false;
unsigned matchSpeedIndex=1; // 0 relaxed, 1 normal, 2 fast
ULONGLONG lastPlaybackTick=0, pitchTransitionTick=0;
fu::PitchFrame previousPitch, currentPitch;
constexpr UINT_PTR PITCH_TIMER=711;
constexpr int PITCH_TICK_MS=33;
int matchPlaybackDelay(){return matchSpeedIndex==0?1000:matchSpeedIndex==1?570:300;}
void updatePitchFrame(bool snap=false){
    if(!started||page!=4)return;
    fu::PitchFrame next=game().pitchFrame();
    const bool newFixture=next.homeClub!=currentPitch.homeClub||
                          next.awayClub!=currentPitch.awayClub;
    bool changed=newFixture||next.minute!=currentPitch.minute||
         next.ballX!=currentPitch.ballX||next.ballY!=currentPitch.ballY||
         next.actors.size()!=currentPitch.actors.size();
    if(!changed)return;
    previousPitch=(snap||newFixture||currentPitch.homeClub<0)?next:currentPitch;
    currentPitch=std::move(next);
    pitchTransitionTick=GetTickCount64();
}

int historyView=0; // 0 calendar, 1 cups, 2 winners, 3 scorers
std::vector<int> visibleIds;
std::vector<int> activeNavigation;
int lastListIndex=0;
std::wstring detailText;
const std::wstring navLabels[]={L"Обзор клуба",L"Состав",L"Тактика",L"Тренировки",L"Матч",L"Турнирная таблица",L"Трансферы",L"Контракты",L"Разговоры",L"Болельщики",L"Финансы",L"Академия",L"Почта",L"Календарь / кубки",L"Настройки",L"Карьера тренера",L"Подготовка к матчу",L"Мировой рынок",L"Сохранения"};
static_assert(sizeof(navLabels)/sizeof(navLabels[0])==NAV_COUNT);
const int NAV_START=100, ACTION_START=300, LIST_ID=501, SETUP_START=600, SETUP_LOAD=601, SETUP_CLUB=602, SETUP_LEAGUES=603;
constexpr int SEARCH_NAME=700,SEARCH_POSITION=701,SEARCH_AGE=702,SEARCH_PRICE=703,
              SEARCH_SORT=704,SEARCH_APPLY=705,SEARCH_RESET=706;
std::string saveFile="career.fus";

std::wstring wide(const std::string& s){
    if(s.empty())return {};
    int count=MultiByteToWideChar(CP_UTF8,0,s.data(),int(s.size()),nullptr,0);
    if(count<=0)return L"[Ошибка кодировки]";
    std::wstring w(count,L'\0');MultiByteToWideChar(CP_UTF8,0,s.data(),int(s.size()),w.data(),count);
    return w;
}
std::string utf8(const std::wstring& w){
    if(w.empty())return {};
    int count=WideCharToMultiByte(CP_UTF8,0,w.data(),int(w.size()),nullptr,0,nullptr,nullptr);
    std::string s(count,'\0');WideCharToMultiByte(CP_UTF8,0,w.data(),int(w.size()),s.data(),count,nullptr,nullptr);return s;
}
std::wstring getText(HWND h){
    int n=GetWindowTextLengthW(h);
    std::wstring s(size_t(n)+1,L'\0');GetWindowTextW(h,s.data(),n+1);s.resize(n);return s;
}
void setText(HWND h,const std::string& text){
    std::wstring w=wide(text),out;
    out.reserve(w.size()+w.size()/20);
    for(size_t i=0;i<w.size();++i){
        if(w[i]==L'\n'&&(i==0||w[i-1]!=L'\r'))out+=L'\r';
        out+=w[i];
    }
    SetWindowTextW(h,out.c_str());
}
std::wstring money(int v){std::wostringstream o;o<<std::fixed<<std::setprecision(1)<<v/1000000.0<<L" млн €";return o.str();}
HWND create(const wchar_t* kind, const wchar_t* label,DWORD style,int id=0,DWORD ex=0,HWND parent=nullptr){
    HWND wnd=CreateWindowExW(ex,kind,label,style|WS_CLIPSIBLINGS,0,0,100,30,parent?parent:mainWindow,HMENU(INT_PTR(id)),appInstance,nullptr);
    SendMessageW(wnd,WM_SETFONT,WPARAM(uiFont),TRUE);return wnd;
}
void show(HWND wnd,bool visible){if(wnd)ShowWindow(wnd,visible?SW_SHOW:SW_HIDE);}
void move(HWND wnd,int x,int y,int w,int h){
    if(wnd)SetWindowPos(wnd,nullptr,x,y,std::max(0,w),std::max(0,h),
                        SWP_NOZORDER|SWP_NOACTIVATE|SWP_NOCOPYBITS);
}
void fillCombo(HWND combo,const std::vector<std::wstring>& items,int defaultItem){
    SendMessageW(combo,CB_RESETCONTENT,0,0);
    for(const auto& s:items)SendMessageW(combo,CB_ADDSTRING,0,LPARAM(s.c_str()));
    SendMessageW(combo,CB_SETCURSEL,WPARAM(defaultItem),0);
}
void addList(std::wstring title,int id){
    SendMessageW(listControl,LB_ADDSTRING,0,LPARAM(title.c_str()));visibleIds.push_back(id);
}
int selectedId(){int pos=int(SendMessageW(listControl,LB_GETCURSEL,0,0));return pos>=0&&pos<int(visibleIds.size())?visibleIds[pos]:-1;}
void textContent(const std::string& content){setText(mainText,content);SendMessageW(mainText,EM_SETSEL,0,0);SendMessageW(mainText,EM_SCROLLCARET,0,0);}
void tell(const std::string& result){setText(statusText,result);}
std::filesystem::path careerSlotPath(int slot){
    if(slot==0)return saveFile;
    return std::filesystem::path("saves")/("slot"+std::to_string(std::clamp(slot,1,3))+".fus");
}
void resetPlayback(){
    autoPlayMatch=false;previousPitch={};currentPitch={};lastPlaybackTick=0;pitchTransitionTick=0;
}
void showSearchControls(bool visible){
    for(auto control:{searchName,searchPosition,searchAge,searchPrice,searchSort,searchApply,searchReset,searchCount})show(control,visible);
    for(auto label:searchLabels)show(label,visible);
}
void resetPlayerSearch(){
    marketFilter=fu::PlayerSearchFilter{};shortlistOnly=false;
    SetWindowTextW(searchName,L"");SetWindowTextW(searchAge,L"50");SetWindowTextW(searchPrice,L"500000000");
    SendMessageW(searchPosition,CB_SETCURSEL,0,0);SendMessageW(searchSort,CB_SETCURSEL,0,0);
}
bool readPlayerSearch(){
    auto filter=marketFilter;
    filter.name=utf8(getText(searchName));
    const int position=int(SendMessageW(searchPosition,CB_GETCURSEL,0,0));
    filter.position=position<=0?std::string{}:utf8(getText(searchPosition));
    auto number=[](HWND control,int fallback,int maximum){
        const std::wstring value=getText(control);
        if(value.empty())return fallback;
        size_t consumed=0;
        const long long parsed=std::stoll(value,&consumed);
        if(consumed!=value.size()||parsed<0||parsed>maximum)throw std::out_of_range("filter");
        return int(parsed);
    };
    try{
        filter.maxAge=number(searchAge,50,100);
        filter.maxValue=number(searchPrice,500000000,2000000000);
    }catch(...){tell("Возраст: 15–100. Цена: целое число от 0 до 2 000 000 000 €.");return false;}
    if(filter.maxAge<15){tell("Максимальный возраст должен быть не меньше 15 лет.");return false;}
    const int sort=int(SendMessageW(searchSort,CB_GETCURSEL,0,0));
    filter.sort=static_cast<fu::PlayerSort>(std::clamp(sort,0,5));
    filter.shortlistOnly=shortlistOnly;
    marketFilter=std::move(filter);return true;
}
std::string playerDetails(int id){
    const fu::Player* p=game().findPlayer(id);
    if(!p)return "Выберите игрока из списка.";
    std::ostringstream o;
    o<<"ID: "<<p->id<<" | "<<p->name<<" / "<<p->position<<" / "<<p->age<<" лет\n";
    o<<"Статус: "<<(p->starter?"ОСНОВА":"ЗАПАС")<<"\n";
    static const char* focusNames[]={"Скорость","Удар","Пас","Отбор","Техника","Сила","Видение поля","Выносливость","Решения","Вратарское мастерство"};
    o<<"Индивидуальный фокус: "<<(p->trainingFocus<0?"Командный план":focusNames[p->trainingFocus])<<"\n\n";
    o<<"Клуб: "<<(game().findClub(p->club)?game().findClub(p->club)->name:std::string("—"))<<"\n";
    static const char* names[]={"Скорость","Удар","Пас","Отбор","Техника","Сила","Видение поля","Выносливость","Решения","Игра в воротах"};
    for(int i=0;i<10;++i)o<<names[i]<<": "<<p->skill[i]<<"/100\n";
    o<<"\nПотенциал: "<<p->potential<<"/100\n";
    o<<"Мораль: "<<p->morale<<"/100\nФорма: "<<p->fitness<<"/100\nДоверие: "<<p->trust<<"/100\n";
    o<<"Благополучие семьи: "<<p->family<<"/100\n";
    o<<"Характер: "<<p->personality<<"\n";
    o<<"Зарплата: "<<p->wage<<" € в неделю\nСтоимость: "<<p->value<<" €\n";
    o<<"Контракт до: "<<p->contractYear<<"\n";
    o<<"Отступные: "<<(p->releaseClause?std::to_string(p->releaseClause)+" €":"нет")<<"\n";
    if(p->sellOnPct)o<<"Процент от перепродажи: "<<p->sellOnPct<<"% в пользу клуба #"<<p->sellOnClub<<"\n";
    if(p->parentClub>=0)o<<"АРЕНДА: принадлежит клубу #"<<p->parentClub
        <<", вернётся через "<<std::max(0,p->loanReturnDay-game().totalDays())
        <<" дн., доля зарплаты "<<p->loanWageShare<<"%\n";
    if(p->club==game().teamId()){
        if(game().myClub().captainId==p->id)o<<"РОЛЬ: КАПИТАН\n";
        if(game().myClub().viceCaptainId==p->id)o<<"РОЛЬ: ВИЦЕ-КАПИТАН\n";
    }
    if(p->injured)o<<"Травма: ещё "<<p->injured<<" дней\n";
    if(p->suspension)o<<"Дисквалификация: "<<p->suspension<<" матча\n";
    o<<"Голы / ассисты за сезон: "<<p->goals<<" / "<<p->assists<<"\n";
    if(!p->sourceQid.empty()){
        if(p->sourceQid.rfind("WC:",0)==0)
            o<<"РЕАЛЬНЫЙ ФУТБОЛИСТ: World Cup 2026 #"<<p->sourceQid.substr(3)
             <<" | клуб указан на лето 2026 г.\n";
        else
            o<<"РЕАЛЬНЫЙ ФУТБОЛИСТ: Wikidata "<<p->sourceQid
             <<" | состав из Википедии (2026)\n";
    }
    else o<<"СГЕНЕРИРОВАННЫЙ ИГРОК (демо)\n";
    o<<"Навыки, трансферная стоимость и зарплата — игровые оценки, не данные FIFA/FM.\n";
    o<<"\n"<<game().worldMarketText(id);
    return o.str();
}
bool roleHasPage(int screen){
    if(!started||game().difficulty()==fu::Difficulty::Free||
       game().role()==fu::Role::Sandbox)return true;
    switch(game().role()){
    case fu::Role::Coach: return screen!=9;
    case fu::Role::Director: return screen!=2&&screen!=3&&screen!=8&&
             screen!=9&&screen!=15&&screen!=PREPARATION_PAGE;
    case fu::Role::Owner: return screen==0||screen==1||screen==4||screen==5||
             screen==10||screen==11||screen==12||screen==13||
             screen==14||screen==SAVES_PAGE;
    case fu::Role::President: return screen==0||screen==1||screen==4||
             screen==5||screen==9||screen==10||screen==11||
             screen==12||screen==13||screen==14||screen==SAVES_PAGE;
    case fu::Role::Sandbox: return true;
    }
    return false;
}
bool actionAllowed(int screen,int action){
    const bool coach=game().canCoach(),sport=game().canTransfer();
    const bool invest=game().canInvest(),commerce=game().canCommercial();
    switch(screen){
    case 1:return action==3?sport:coach;
    case 2:case 3:case 8:case PREPARATION_PAGE:return action==5||coach;
    case 4:return (action!=3&&action!=5)||coach;
    case 6:return action==3||sport;
    case 7:return action==1||sport;
    case 9:return commerce;
    case 10:return action<3?invest:commerce;
    case 11:
        if(action<=1)return sport;
        if(action==2||action==5)return sport||invest||commerce;
        return coach;
    case WORLD_MARKET_PAGE:
        return action!=3||coach;
    case 15:return action>=3||coach;
    default:return true;
    }
}
void arrange(){
    if(!mainWindow)return;
    RECT r{};GetClientRect(mainWindow,&r);
    const int w=std::max(1,int(r.right-r.left)),h=std::max(1,int(r.bottom-r.top));
    if(w<580||h<440)return; // Incomplete WM_SIZE during minimize.
    const int sidebarWidth=std::clamp(w/5,165,215);
    const int left=sidebarWidth+12,right=w-20,bodyWidth=right-left;
    if(!started){
        move(titleText,45,25,w-215,48);move(subtitleText,45,78,w-215,35);
        move(clubLogoWindow,w-150,24,105,105);
        move(setupName,45,160,400,35);move(setupClub,45,215,400,300);
        move(setupRole,45,270,400,230);move(setupDifficulty,45,325,400,230);
        move(setupLeagues,470,160,std::max(300,w-515),270);
        move(setupHelp,45,387,400,150);
        move(setupStart,45,550,220,44);move(setupLoad,277,550,220,44);
        move(statusText,40,h-52,w-80,36);
    }else{
        move(titleText,left,24,bodyWidth-100,40);
        move(subtitleText,left,65,bodyWidth-100,22);
        move(clubLogoWindow,right-85,12,82,82);
        // Adaptive navigation: prevent the bottom items from overlapping the status bar.
        int visibleNav=0;
        for(int i=0;i<NAV_COUNT;++i)if(roleHasPage(i))++visibleNav;
        const int navStep=std::clamp((h-162)/std::max(1,visibleNav),20,37);
        int row=0;
        for(int i=0;i<NAV_COUNT;++i)if(roleHasPage(i))
            move(nav[i],10,74+row++*navStep,sidebarWidth-18,
                 std::max(18,navStep-2));
        bool listNeeded=page==1||page==3||page==4||page==5||page==6||page==7||page==8||page==11||page==12||page==14||page==15||page==SAVES_PAGE;
        bool pitchNeeded=(page==4&&showPitch);
        int contentY=page==6?210:102;
        int contentH=std::max(85,h-284-(contentY-102));
        if(page==6){
            const int nameW=bodyWidth*34/100,positionW=100,ageW=95;
            const int priceW=bodyWidth-nameW-positionW-ageW-24;
            const int positions[]={left,left+nameW+8,left+nameW+positionW+16,left+nameW+positionW+ageW+24};
            const int widths[]={nameW,positionW,ageW,priceW};
            const HWND fields[]={searchName,searchPosition,searchAge,searchPrice};
            for(int i=0;i<4;++i){
                move(searchLabels[i],positions[i],99,widths[i],21);
                move(fields[i],positions[i],122,widths[i],i==1?360:29);
            }
            move(searchLabels[4],left,158,105,21);
            move(searchSort,left+108,155,190,250);
            move(searchApply,left+308,155,105,31);
            move(searchReset,left+421,155,92,31);
            move(searchCount,left+521,157,bodyWidth-521,40);
        }
        if(listNeeded){
            if(pitchNeeded){
                // Match mode: dominant animated stadium, match commentary below,
                // selection/substitutions to the right (no text overlays).
                const int side=std::clamp(bodyWidth*31/100,175,320);
                const int pitchW=std::max(145,bodyWidth-side-12);
                const int pitchH=std::clamp(contentH*65/100,100,std::max(100,contentH-48));
                move(pitchWindow,left,contentY,pitchW,pitchH);
                move(mainText,left,contentY+pitchH+8,pitchW,std::max(50,contentH-pitchH-8));
                move(listControl,left+pitchW+12,contentY,side,contentH);
            }else{
                int listWidth=std::clamp(bodyWidth*39/100,175,360);
                move(listControl,left,contentY,listWidth,contentH);
                int textX=left+listWidth+12,textW=bodyWidth-listWidth-12;
                move(mainText,textX,contentY,textW,contentH);
            }
        }else if(pitchNeeded){
            int textW=bodyWidth*48/100;
            move(mainText,left,contentY,textW,contentH);
            move(pitchWindow,left+textW+14,contentY,bodyWidth-textW-14,contentH);
        }else move(mainText,left,contentY,bodyWidth,contentH);
        move(inputControl,left,h-168,bodyWidth,37);
        int buttonW=std::max(65,(bodyWidth-5*8)/5);
        for(int i=0;i<5;++i)move(actions[i],left+i*(buttonW+8),h-120,buttonW,39);
        move(actions[5],left,h-74,buttonW,32);
        move(statusText,left+buttonW+12,h-74,bodyWidth-buttonW-12,34);
    }
}
std::vector<std::wstring> buttonTexts(int p){
    switch(p){
        case 0:return {L"День +1",L"До матча (+7)",L"Сохранить",L"Загрузить",L"Подготовка"};
        case 1:return {L"В основу",L"Автосостав",L"Разговор",L"Контракт",L"Капитан"};
        case 2:return {L"Сменить схему",L"Сменить стиль",L"Прессинг",L"Темп",L"Ширина"};
        case 3:return {L"План команды",L"Фокус игрока",L"Состав",L"День +1",L"Наставник"};
        case 4:return {L"Начать / +15",L"▶ Авто / Пауза",L"Мгновенно",L"Сменить тактику",L"2D / текст"};
        case 5:return {L"Лига клуба",L"Другая лига",L"Кубки",L"Календарь",L"Обновить"};
        case 6:return {L"Оффер / аренда",L"Скаутировать",L"В список / убрать",L"Короткий список",L"Принять условия"};
        case 7:return {L"Контракт",L"Состав",L"Продать",L"Отступные",L"—"};
        case 8:return {L"Отправить текст",L"Похвалить",L"Помочь семье",L"Собрание",L"Похвала команде"};
        case 9:return {L"Обратиться",L"Поблагодарить",L"Встреча",L"Обновить",L"—"};
        case 10:return {L"Стадион",L"Трениров. база",L"Академия",L"Спонсор",L"Билет +5 €"};
        case 11:return {L"Подписать игрока",L"Поиск талантов",L"Нанять штаб",L"Наставник",L"Отношения"};
        case 12:return {L"Обновить",L"Обзор",L"—",L"—",L"—"};
        case 13:return {L"Календарь",L"Кубки",L"Победители",L"Бомбардиры",L"Отчёт матча"};
        case 14:return {L"Вкл./выкл. лигу",L"Новая карьера",L"Сохранить",L"Загрузить",L"Реальная база"};
        case 15:return {L"Подать заявку",L"Принять оффер",L"Отозвать",L"Рынок тренеров",L"Справка"};
        case PREPARATION_PAGE:return {L"Баланс",L"Контроль мяча",L"Прессинг",L"Контратаки",L"Удержать счёт"};
        case WORLD_MARKET_PAGE:return {L"Обновить",L"Трансферы",L"Календарь",L"Подготовка",L"Сохранить"};
        case SAVES_PAGE:return {L"Сохранить",L"Загрузить",L"Из копии",L"Обзор",L"Обновить"};
        default:return {L"Обзор",L"—",L"—",L"—",L"—"};
    }
}
void drawPitch(HDC dc,RECT area){
    const int w=std::max(1,int(area.right-area.left));
    const int h=std::max(1,int(area.bottom-area.top));
    Gdiplus::Bitmap back(w,h,PixelFormat32bppARGB);
    Gdiplus::Graphics g(&back);
    g.SetSmoothingMode(Gdiplus::SmoothingModeAntiAlias);
    g.SetTextRenderingHint(Gdiplus::TextRenderingHintAntiAlias);
    Gdiplus::SolidBrush midnight(Gdiplus::Color(255,10,24,30));
    g.FillRectangle(&midnight,0,0,w,h);
    const Gdiplus::RectF pitch(17.f,53.f,float(std::max(30,w-34)),
                             float(std::max(40,h-88)));
    const float cw=pitch.Width,ch=pitch.Height;
    for(int stripe=0;stripe<10;++stripe){
        Gdiplus::SolidBrush green(stripe%2?
            Gdiplus::Color(255,22,91,68):Gdiplus::Color(255,19,104,76));
        g.FillRectangle(&green,pitch.X+cw*stripe/10.f,pitch.Y,cw/10.f+1.f,ch);
    }
    Gdiplus::Pen marks(Gdiplus::Color(230,214,242,223),1.5f);
    Gdiplus::Pen thin(Gdiplus::Color(180,213,240,223),1.f);
    g.DrawRectangle(&marks,pitch);
    g.DrawLine(&marks,pitch.X+cw/2,pitch.Y,pitch.X+cw/2,pitch.Y+ch);
    g.DrawEllipse(&marks,pitch.X+cw/2-std::min(40.f,ch*.2f),
        pitch.Y+ch/2-std::min(40.f,ch*.2f),
        std::min(80.f,ch*.4f),std::min(80.f,ch*.4f));
    g.DrawEllipse(&marks,pitch.X+cw/2-2,pitch.Y+ch/2-2,4.f,4.f);
    for(int team=0;team<2;++team){
        const float edge=team==0?pitch.X:pitch.X+cw;
        const float boxW=cw*.14f,smallW=cw*.055f;
        const float bx=team==0?edge:edge-boxW;
        const float sx=team==0?edge:edge-smallW;
        g.DrawRectangle(&thin,bx,pitch.Y+ch*.21f,boxW,ch*.58f);
        g.DrawRectangle(&thin,sx,pitch.Y+ch*.35f,smallW,ch*.30f);
        g.DrawEllipse(&thin,(team==0?bx+boxW-2:bx-17),
            pitch.Y+ch/2-16,19.f,32.f);
        Gdiplus::SolidBrush whiteNet(Gdiplus::Color(255,229,237,243));
        const float gx=team==0?pitch.X-7:pitch.X+cw;
        g.FillRectangle(&whiteNet,gx,pitch.Y+ch*.43f,7.f,ch*.14f);
    }
    Gdiplus::FontFamily fontFamily(L"Segoe UI");
    Gdiplus::Font title(&fontFamily,16.f,Gdiplus::FontStyleBold,Gdiplus::UnitPixel);
    Gdiplus::Font normal(&fontFamily,12.f,Gdiplus::FontStyleRegular,Gdiplus::UnitPixel);
    Gdiplus::Font number(&fontFamily,10.f,Gdiplus::FontStyleBold,Gdiplus::UnitPixel);
    Gdiplus::SolidBrush ink(Gdiplus::Color(255,238,246,247));
    Gdiplus::SolidBrush hint(Gdiplus::Color(255,173,203,202));
    Gdiplus::SolidBrush gold(Gdiplus::Color(255,253,207,85));
    const fu::PitchFrame& frame=currentPitch;
    std::wstring left=L"ДОМА",right=L"ГОСТИ";
    if(frame.homeClub>=0){
        if(const auto* club=game().findClub(frame.homeClub))left=wide(club->name);
        if(const auto* club=game().findClub(frame.awayClub))right=wide(club->name);
    }
    if(left.size()>19)left.resize(19);
    if(right.size()>19)right.resize(19);
    const std::wstring score=std::to_wstring(frame.homeGoals)+L" : "+
                             std::to_wstring(frame.awayGoals);
    const std::wstring clock=game().hasLiveMatch()?
        std::to_wstring(frame.minute)+L"'  LIVE":
        (frame.minute==90?L"90' FIN":L"ПРЕВЬЮ");
    g.DrawString(left.c_str(),-1,&title,Gdiplus::PointF(16.f,8.f),&ink);
    const float scoreX=std::max(140.f,float(w)/2-31.f);
    g.DrawString(score.c_str(),-1,&title,Gdiplus::PointF(scoreX,6.f),&gold);
    Gdiplus::RectF rightRect(float(w)-190.f,8.f,173.f,24.f);
    Gdiplus::StringFormat rightAlign;
    rightAlign.SetAlignment(Gdiplus::StringAlignmentFar);
    g.DrawString(right.c_str(),-1,&title,rightRect,&rightAlign,&ink);
    g.DrawString(clock.c_str(),-1,&normal,Gdiplus::PointF(18.f,31.f),&hint);
    const wchar_t* controls=L"ЛКМ: ▶ / пауза   |   ПКМ: скорость   |   +15 мин: кнопка";
    g.DrawString(controls,-1,&normal,
        Gdiplus::PointF(17.f,float(h)-27.f),&hint);
    auto px=[&](float x){return pitch.X+cw*x/1000.f;};
    auto py=[&](float y){return pitch.Y+ch*y/700.f;};
    const ULONGLONG now=GetTickCount64();
    const float factor=std::clamp(float(now-pitchTransitionTick)/
                float(std::max(200,matchPlaybackDelay()-60)),0.f,1.f);
    const float eased=factor*factor*(3.f-2.f*factor);
    for(const auto& actor:frame.actors){
        float ax=float(actor.x),ay=float(actor.y);
        if(previousPitch.homeClub==frame.homeClub&&
           previousPitch.awayClub==frame.awayClub){
            for(const auto& old:previousPitch.actors)
                if(old.playerId==actor.playerId){
                    ax=float(old.x)+(actor.x-old.x)*eased;
                    ay=float(old.y)+(actor.y-old.y)*eased;
                    break;
                }
        }
        const float x=px(ax),y=py(ay);
        const float radius=std::clamp(ch*.025f,7.f,11.f);
        const Gdiplus::Color base=actor.team==0?
             Gdiplus::Color(255,69,161,248):
             Gdiplus::Color(255,247,109,92);
        Gdiplus::SolidBrush shade(Gdiplus::Color(110,0,0,0));
        g.FillEllipse(&shade,x-radius+2.f,y-radius+3.f,2*radius,2*radius);
        if(actor.playerId==frame.carrierId){
            Gdiplus::Pen selected(Gdiplus::Color(230,252,206,82),2.4f);
            g.DrawEllipse(&selected,x-radius-4.f,y-radius-4.f,
                         2*radius+8.f,2*radius+8.f);
        }
        Gdiplus::SolidBrush kit(base);
        Gdiplus::Pen border(Gdiplus::Color(255,232,246,248),1.3f);
        g.FillEllipse(&kit,x-radius,y-radius,2*radius,2*radius);
        g.DrawEllipse(&border,x-radius,y-radius,2*radius,2*radius);
        const std::wstring shirt=std::to_wstring(actor.playerId%99+1);
        Gdiplus::RectF nr(x-radius,y-radius+1.f,2*radius,2*radius-2.f);
        Gdiplus::StringFormat middle;middle.SetAlignment(Gdiplus::StringAlignmentCenter);
        middle.SetLineAlignment(Gdiplus::StringAlignmentCenter);
        g.DrawString(shirt.c_str(),-1,&number,nr,&middle,&ink);
    }
    if(frame.homeClub>=0){
        // The ball is connected to the actual carrier/pass/shot event at this minute.
        // Interpolation is visual only: it never changes the underlying match result.
        const float fromX=px(float(frame.ballFromX));
        const float fromY=py(float(frame.ballFromY));
        const float endX=px(float(frame.ballX));
        const float endY=py(float(frame.ballY));
        const float ballX=fromX+(endX-fromX)*eased;
        const float ballY=fromY+(endY-fromY)*eased;
        if(frame.action==1||frame.action==2||frame.action==3){
            Gdiplus::Pen trail(Gdiplus::Color(180,255,229,129),2.f);
            trail.SetDashStyle(Gdiplus::DashStyleDash);
            g.DrawLine(&trail,fromX,fromY,endX,endY);
        }
        Gdiplus::SolidBrush glow(Gdiplus::Color(85,255,229,113));
        Gdiplus::SolidBrush ball(Gdiplus::Color(255,255,254,239));
        Gdiplus::Pen outline(Gdiplus::Color(255,20,37,35),1.5f);
        g.FillEllipse(&glow,ballX-9.f,ballY-9.f,18.f,18.f);
        g.FillEllipse(&ball,ballX-4.6f,ballY-4.6f,9.2f,9.2f);
        g.DrawEllipse(&outline,ballX-4.6f,ballY-4.6f,9.2f,9.2f);
    }
    if(frame.action==3&&game().hasLiveMatch()){
        Gdiplus::SolidBrush celebration(Gdiplus::Color(215,13,32,38));
        const float bw=std::min(cw*.42f,210.f), bh=48.f;
        g.FillRectangle(&celebration,pitch.X+(cw-bw)/2,
                         pitch.Y+(ch-bh)/2,bw,bh);
        Gdiplus::Font shout(&fontFamily,29.f,Gdiplus::FontStyleBold,
                            Gdiplus::UnitPixel);
        Gdiplus::RectF label(pitch.X+(cw-bw)/2,pitch.Y+(ch-bh)/2,bw,bh);
        Gdiplus::StringFormat centered;
        centered.SetAlignment(Gdiplus::StringAlignmentCenter);
        centered.SetLineAlignment(Gdiplus::StringAlignmentCenter);
        g.DrawString(L"ГОЛ!",-1,&shout,label,&centered,&gold);
    }
    if(!frame.highlight.empty()){
        const auto text=wide(frame.highlight);
        const float panelHeight=23.f;
        const float bottom=pitch.Y+ch-panelHeight-3.f;
        Gdiplus::SolidBrush overlay(Gdiplus::Color(205,5,31,28));
        g.FillRectangle(&overlay,pitch.X+3.f,bottom,cw-6.f,panelHeight);
        Gdiplus::RectF box(pitch.X+10.f,bottom+2.f,cw-20.f,panelHeight-3.f);
        Gdiplus::StringFormat clip;
        clip.SetTrimming(Gdiplus::StringTrimmingEllipsisCharacter);
        clip.SetFormatFlags(Gdiplus::StringFormatFlagsNoWrap);
        g.DrawString(text.c_str(),-1,&normal,box,&clip,&ink);
    }
    Gdiplus::Graphics screen(dc);
    screen.DrawImage(&back,0,0);
}
LRESULT CALLBACK pitchProc(HWND hwnd,UINT msg,WPARAM w,LPARAM l){
    if(msg==WM_LBUTTONDOWN){
        SendMessageW(mainWindow,WM_COMMAND,MAKEWPARAM(ACTION_START+1,BN_CLICKED),
                     LPARAM(actions[1]));
        return 0;
    }
    if(msg==WM_RBUTTONDOWN){
        matchSpeedIndex=(matchSpeedIndex+1)%3;
        lastPlaybackTick=GetTickCount64();
        const std::string label=matchSpeedIndex==0?"x1":matchSpeedIndex==1?"x2":"x4";
        tell("Скорость матча "+label+".");
        return 0;
    }
    if(msg==WM_ERASEBKGND)return 1;
    if(msg==WM_PAINT){PAINTSTRUCT ps;HDC dc=BeginPaint(hwnd,&ps);RECT r;GetClientRect(hwnd,&r);drawPitch(dc,r);EndPaint(hwnd,&ps);return 0;}
    return DefWindowProcW(hwnd,msg,w,l);
}
// PNG logos are optional. Place files in assets/clubs/<club_id>.png next to the executable.
// Club IDs are stable in this demo database; see assets/clubs/CLUB_IDS.csv.
LRESULT CALLBACK logoProc(HWND hwnd,UINT msg,WPARAM w,LPARAM l){
    if(msg==WM_ERASEBKGND)return 1;
    if(msg==WM_PAINT){
        PAINTSTRUCT ps{};HDC dc=BeginPaint(hwnd,&ps);
        RECT r{};GetClientRect(hwnd,&r);
        Gdiplus::Graphics graphics(dc);
        graphics.SetSmoothingMode(Gdiplus::SmoothingModeAntiAlias);
        graphics.SetInterpolationMode(Gdiplus::InterpolationModeHighQualityBicubic);
        Gdiplus::SolidBrush bg(Gdiplus::Color(13,21,35));
        graphics.FillRectangle(&bg,0,0,r.right,r.bottom);
        int clubId=0;
        if(started){ clubId=game().teamId(); }
        else if(setupClub){
            int index=int(SendMessageW(setupClub,CB_GETCURSEL,0,0));
            if(index>=0&&index<int(game().clubs().size()))clubId=game().clubs()[index].id;
        }
        const fu::Club* club=game().findClub(clubId);
        wchar_t modulePath[MAX_PATH]{};
        GetModuleFileNameW(nullptr,modulePath,MAX_PATH);
        std::filesystem::path logoPath=std::filesystem::path(modulePath).parent_path()/L"assets"/L"clubs"/(std::to_wstring(clubId)+L".png");
        bool hasLogo=false;
        if(std::filesystem::exists(logoPath)){
            Gdiplus::Bitmap image(logoPath.c_str());
            if(image.GetLastStatus()==Gdiplus::Ok&&image.GetWidth()>0&&image.GetHeight()>0){
                int inset=4;int side=std::min(r.right,r.bottom)-2*inset;
                graphics.DrawImage(&image,Gdiplus::Rect((r.right-side)/2,(r.bottom-side)/2,side,side));
                hasLogo=true;
            }
        }
        if(!hasLogo){
            int side=std::min(r.right,r.bottom)-10, cx=r.right/2,cy=r.bottom/2;
            Gdiplus::SolidBrush fill(Gdiplus::Color(255,29,61,99));
            Gdiplus::Pen outline(Gdiplus::Color(255,67,202,179),2.0f);
            graphics.FillEllipse(&fill,cx-side/2,cy-side/2,side,side);
            graphics.DrawEllipse(&outline,cx-side/2,cy-side/2,side,side);
            std::wstring label=club?wide(club->name):L"FC";
            if(label.size()>2)label=label.substr(0,2);
            Gdiplus::FontFamily family(L"Segoe UI");
            Gdiplus::Font font(&family,28.0f,Gdiplus::FontStyleBold,Gdiplus::UnitPixel);
            Gdiplus::SolidBrush ink(Gdiplus::Color(255,233,239,247));
            Gdiplus::StringFormat format;format.SetAlignment(Gdiplus::StringAlignmentCenter);format.SetLineAlignment(Gdiplus::StringAlignmentCenter);
            Gdiplus::RectF box(0.0f,0.0f,float(r.right),float(r.bottom));
            graphics.DrawString(label.c_str(),-1,&font,box,&format,&ink);
        }
        EndPaint(hwnd,&ps);return 0;
    }
    return DefWindowProcW(hwnd,msg,w,l);
}
void showPage(int next);
void updateTransferOfferInput(){
    const auto* deal=game().transferDeal(selectedId());
    if(deal&&(deal->stage==fu::DealStage::AgentOffer||deal->stage==fu::DealStage::AgentCounter)){
        SetWindowTextW(inputControl,L"55000 3");
    }else if(deal&&deal->stage==fu::DealStage::ClubCounter){
        SetWindowTextW(inputControl,std::to_wstring(deal->askingFee).c_str());
    }else SetWindowTextW(inputControl,L"10000000");
}
void detailForSelected(){
    int id=selectedId();
    if(id<0){
        if(page==11)textContent(game().academyText());
        else if(page==15)textContent(game().jobMarketText());
        else if(page==6)textContent("По заданным фильтрам футболистов нет. Измените ограничения или нажмите «Сброс».\n\nФильтры поиска расположены сверху. Поле внизу предназначено только для трансферного предложения.");
        else textContent("Выберите пункт из списка.");
        return;
    }
    if(page==1)textContent(playerDetails(id)+"\n\n"+game().lineupText());
    else if(page==3)textContent(game().tacticsText()+"\n"+playerDetails(id)+"\n"+
                                 game().developmentText(id)+"\n"+
                                 game().relationshipsText(id)+
                                 "\nНаставник: выберите молодого игрока слева, введите ID наставника.");
    else if(page==6)textContent(playerDetails(id)+"\n\n"+game().scoutText(id)+"\n"+game().negotiationText(id));
    else if(page==7){
        std::ostringstream o;
        o<<playerDetails(id)<<"\nПродажа: укажите ID клуба и цену, например: 6 3000000\n";
        o<<"Отступные: укажите сумму, например 50000000 (0 отключает условие).\n";
        o<<"ID клубов-покупателей:\n";
        int count=0;
        for(const auto& c:game().clubs()){
            if(c.id==game().teamId())continue;
            if(count++>=12)break;
            o<<"#"<<c.id<<" "<<c.name<<" | бюджет: "<<c.budget<<" €\n";
        }
        textContent(o.str());
    }
    else if(page==8)textContent(playerDetails(id)+"\n"+game().relationshipsText(id));
    else if(page==11)textContent(game().academyText());
    else if(page==5)textContent(game().standings(id));
    else if(page==15)textContent(game().jobMarketText(id));
    else if(page==SAVES_PAGE)textContent((id==0?"БЫСТРОЕ СОХРАНЕНИЕ":("СЛОТ "+std::to_string(id)))+"\n\n"+
        fu::careerSlotSummary(careerSlotPath(id))+"\n\nФайл: "+careerSlotPath(id).generic_string()+
        "\n\nПри сохранении создаётся резервная копия предыдущей версии.\n«Из копии» загружает резервную версию, сохраняя основной файл.");
    else if(page==12){const auto& inbox=game().inbox();if(id>=0&&id<int(inbox.size()))textContent(inbox[id].title+"\n\n"+inbox[id].body);}
    else if(page==14){const auto& l=game().leagues();if(id>=0&&id<int(l.size()))textContent(game().standings(id)+"\n\nНажмите «Вкл./выкл. лигу», чтобы переключить детализацию.\nКлубная лига всегда активна.");}
}
void populate(){
    visibleIds.clear();SendMessageW(listControl,LB_RESETCONTENT,0,0);
    if(page==1||page==3||page==4||page==7||page==8){
        for(int id:game().ownPlayers()){
            const auto* p=game().findPlayer(id);if(!p)continue;
            std::string marker=p->starter?"[ОСН] ":"[ЗАП] ";
            if(page==4&&game().hasLiveMatch()){
                const auto& live=game().live();
                const bool home=game().upcomingMatch()&&game().upcomingMatch()->home==game().teamId();
                const auto& xi=home?live.homeXI:live.awayXI;
                const auto& used=home?live.usedHome:live.usedAway;
                if(std::find(xi.begin(),xi.end(),p->id)!=xi.end())marker="[ПОЛЕ] ";
                else if(std::find(used.begin(),used.end(),p->id)!=used.end())marker="[ВЫШЕЛ] ";
                else marker="[ЗАП] ";
            }
            addList(wide("#"+std::to_string(p->id)+" "+marker+p->position+" "+p->name+(p->injured?" [ТРАВМА]":"")),id);
        }
    }else if(page==6){
        marketFilter.shortlistOnly=shortlistOnly;
        const auto results=fu::searchPlayers(game(),marketFilter);
        setText(searchCount,"Найдено: "+std::to_string(results.size()));
        for(int id:results){
            const auto* p=game().findPlayer(id);if(!p)continue;
            const auto* report=game().scoutReport(id);
            std::string marker=report&&report->shortlisted?"[*] ":report&&report->days>=5?"[ОТЧЁТ] ":"";
            if(const auto* d=game().transferDeal(id)){
                if(int(d->stage)<=4)marker="[СДЕЛКА] "+marker;
            }
            addList(wide("#"+std::to_string(id)+" "+marker+p->position+" | "+p->name+
                " | "+std::to_string(p->age)+" лет | "+std::to_string(p->value)+" €"),id);
        }
    }else if(page==11){
        for(const auto& p:game().youthProspects())if(p.club==game().teamId()){
            addList(wide("#"+std::to_string(p.id)+" "+p.position+" "+p.name+
                         " | потенциал ~"+std::to_string(p.potential)),p.id);
        }
    }else if(page==5||page==14){
        for(const auto& l:game().leagues()){
            addList(wide(l.country+" • "+l.name+(l.active?" [АКТИВНА]":" [ФОН]")),l.id);
        }
    }else if(page==15){
        for(const auto& c:game().clubs()){
            const auto& coach=game().coaches()[c.id];
            const std::string tag=c.id==game().teamId()?"[ВАШ КЛУБ] ":
                                   coach.vacant?"[ВАКАНСИЯ] ":"";
            addList(wide(tag+c.name+" | "+
                   game().leagues()[c.league].name),c.id);
        }
    }else if(page==12){
        const auto& inbox=game().inbox();
        for(int j=int(inbox.size())-1;j>=0;--j)addList(wide(inbox[j].title),j);
    }else if(page==SAVES_PAGE){
        for(int slot=1;slot<=3;++slot){
            const auto summary=fu::careerSlotSummary(careerSlotPath(slot));
            addList(wide("Слот "+std::to_string(slot)+" | "+summary.substr(0,summary.find('\n'))),slot);
        }
        const auto quickSummary=fu::careerSlotSummary(careerSlotPath(0));
        addList(wide("Быстрое сохранение | "+quickSummary.substr(0,quickSummary.find('\n'))),0);
    }
    if(!visibleIds.empty()){
        int i=std::clamp(lastListIndex,0,int(visibleIds.size())-1);
        SendMessageW(listControl,LB_SETCURSEL,i,0);
    }
}
void showPage(int next){
    if(!started)return;
    const bool samePage=page==next;
    const int preservedId=samePage?selectedId():-1;
    if(next!=4)autoPlayMatch=false;
    page=std::clamp(next,0,NAV_COUNT-1);
    if(!roleHasPage(page))page=0;
    SendMessageW(mainWindow,WM_SETREDRAW,FALSE,0);
    if(!samePage)lastListIndex=0;
    // Owner-draw nav does not automatically repaint when a different page is selected.
    for(auto& button:nav)if(button)InvalidateRect(button,nullptr,TRUE);
    bool listNeeded=page==1||page==3||page==4||page==5||page==6||page==7||page==8||page==11||page==12||page==14||page==15||page==SAVES_PAGE;
    show(listControl,listNeeded);show(inputControl,page==1||page==6||page==7||page==8||page==9||page==11||page==3||(page==4&&game().hasLiveMatch()));
    showSearchControls(page==6);
    show(pitchWindow,page==4&&showPitch);
    for(int i=0;i<NAV_COUNT;++i)show(nav[i],roleHasPage(i));
    auto labels=buttonTexts(page);
    if(page==0&&!game().canCoach())labels[4]=L"Матч";
    for(int i=0;i<5;++i){
        SetWindowTextW(actions[i],labels[i].c_str());
        show(actions[i],labels[i]!=L"—");
        EnableWindow(actions[i],actionAllowed(page,i)?TRUE:FALSE);
    }
    show(actions[5],page==1||page==2||page==6||page==8||page==10||page==11||page==PREPARATION_PAGE||(page==4&&game().hasLiveMatch()));
    EnableWindow(actions[5],actionAllowed(page,5)?TRUE:FALSE);
    SetWindowTextW(actions[5],page==1?L"Вице-капитан":page==6?L"Отменить сделку":page==8?L"Жёсткий разговор":page==11?L"Уволить":page==2?L"Подготовка":page==PREPARATION_PAGE?L"Матч":page==4?L"Заменить":L"Билет −5 €");
    if(page==6)SetWindowTextW(actions[3],shortlistOnly?L"Все игроки":L"Короткий список");
    if(page==4){
        SetWindowTextW(actions[0],game().hasLiveMatch()?L"+15 минут":L"Начать матч");
        SetWindowTextW(actions[1],autoPlayMatch?L"⏸ Пауза":L"▶ Авто");
        updatePitchFrame();
    }
    SetWindowTextW(titleText,navLabels[page].c_str());
    std::wstring roleName=game().role()==fu::Role::Coach?L"ТРЕНЕР":
        game().role()==fu::Role::Director?L"СПОРТДИР":
        game().role()==fu::Role::Owner?L"ВЛАДЕЛЕЦ":
        game().role()==fu::Role::President?L"ПРЕЗИДЕНТ":L"ПЕСОЧНИЦА";
    std::wstring sub=wide(game().myClub().name)+L"   •   "+wide(game().dateString())+
        L"   •   "+roleName+L"   •   Сезон "+std::to_wstring(game().season())+
        L"/"+std::to_wstring((game().season()+1)%100);
    SetWindowTextW(subtitleText,sub.c_str());
    if(page==1)SetWindowTextW(inputControl,L"ID игрока основы");
    if(page==3)SetWindowTextW(inputControl,L"ID наставника");
    if(page==11)SetWindowTextW(inputControl,L"0 80");
    if(page==4)SetWindowTextW(inputControl,L"ID игрока с поля");
    if(page==7)SetWindowTextW(inputControl,L"30000 3");
    if(page==8)SetWindowTextW(inputControl,L"Спасибо за работу! Как у тебя дела?");
    if(page==9)SetWindowTextW(inputControl,L"Спасибо за вашу поддержку клуба!");
    populate();
    if(preservedId>=0){
        const auto found=std::find(visibleIds.begin(),visibleIds.end(),preservedId);
        if(found!=visibleIds.end()){
            lastListIndex=int(found-visibleIds.begin());
            SendMessageW(listControl,LB_SETCURSEL,lastListIndex,0);
        }
    }
    if(page==6)updateTransferOfferInput();
    switch(page){
        case 0:textContent(game().homeText());break;
        case 1:case 3:case 5:case 6:case 7:case 8:case 11:case 12:case 14:case SAVES_PAGE:detailForSelected();break;
        case 2:textContent(game().tacticsText());break;

        case 4:textContent(game().matchText());break;
        case 9:textContent("БОЛЕЛЬЩИКИ\n\nТекущая поддержка: "+std::to_string(game().myClub().fans)+"/100\n\nНапишите своё обращение в поле ниже.\nРеакции имеют последствия для доверия, посещаемости и отношений внутри клуба.\n\nТекст понимается через локальные правила (без облачного ИИ).");break;
        case 10:textContent(game().financesText());break;
        case 13:
            if(historyView==0)textContent(game().calendarText());
            else if(historyView==1)textContent(game().cupsText());
            else if(historyView==2)textContent(game().seasonHistoryText());
            else if(historyView==3)textContent(game().scorersText());
            else textContent(game().latestMatchReport());
            break;
        case 15:detailForSelected();break;
        case PREPARATION_PAGE:textContent(game().preparationText());break;
        case WORLD_MARKET_PAGE:textContent(game().worldMarketText());break;
    }
    tell(game().status());arrange();
    SendMessageW(mainWindow,WM_SETREDRAW,TRUE,0);
    RedrawWindow(mainWindow,nullptr,nullptr,
        RDW_INVALIDATE|RDW_ERASE|RDW_ALLCHILDREN|RDW_UPDATENOW);
    InvalidateRect(pitchWindow,nullptr,TRUE);
    InvalidateRect(clubLogoWindow,nullptr,TRUE);
}
void showSetup(){
    trace("showSetup BEGIN");
    autoPlayMatch=false;
    previousPitch={};currentPitch={};
    started=false;page=-1;
    for(auto& w:nav)show(w,false);
    for(auto& w:actions)show(w,false);
    show(listControl,false);show(mainText,false);show(inputControl,false);show(pitchWindow,false);
    showSearchControls(false);resetPlayerSearch();
    show(setupName,true);show(setupClub,true);show(setupRole,true);show(setupDifficulty,true);
    show(setupLeagues,true);show(setupHelp,true);show(setupStart,true);show(setupLoad,true);
    SetWindowTextW(titleText,L"FOOTBALL UNIVERSE");
    SetWindowTextW(subtitleText,L"Новая карьера • 2026/27 • C++ • Windows");
    SetWindowTextW(setupName,L"Алексей");
    std::vector<std::wstring> clubs;
    for(const auto& c:game().clubs())clubs.push_back(wide(c.name+" ("+game().leagues()[c.league].country+")"));
    fillCombo(setupClub,clubs,0);trace("showSetup clubs populated");
    fillCombo(setupRole,{L"Главный тренер",L"Спортивный директор",L"Владелец клуба",L"Президент клуба",L"Песочница (все полномочия)"},0);
    fillCombo(setupDifficulty,{L"Лёгкая",L"Реалистичная",L"Сложная",L"Свободная песочница"},1);
    SendMessageW(setupLeagues,LB_RESETCONTENT,0,0);
    for(const auto& l:game().leagues())SendMessageW(setupLeagues,LB_ADDSTRING,0,LPARAM(wide(l.country+" — "+l.name).c_str()));
    for(int i=0;i<6;++i)SendMessageW(setupLeagues,LB_SETSEL,i<2,i);
    SetWindowTextW(setupHelp,L"Укажите имя, клуб, должность, сложность.\nВ списке справа отметьте активные лиги (Ctrl/Shift не нужны).\nЛига выбранного клуба включится автоматически.");
    tell("Демо-база: известные клубы, процедурные игроки. Полная лицензированная база ещё не добавлена.");
    trace("showSetup before arrange");show(clubLogoWindow,true);arrange();InvalidateRect(clubLogoWindow,nullptr,TRUE);trace("showSetup END");
}
void startCareer(){
    int club=int(SendMessageW(setupClub,CB_GETCURSEL,0,0));
    int role=int(SendMessageW(setupRole,CB_GETCURSEL,0,0));
    int diff=int(SendMessageW(setupDifficulty,CB_GETCURSEL,0,0));
    std::vector<int> active;
    for(int i=0;i<int(game().leagues().size());++i)if(SendMessageW(setupLeagues,LB_GETSEL,i,0)>0)active.push_back(i);
    game().newCareer(utf8(getText(setupName)),club,fu::Role(std::clamp(role,0,4)),fu::Difficulty(std::clamp(diff,0,3)),active);
    resetPlayerSearch();resetPlayback();
    started=true;
    show(setupName,false);show(setupClub,false);show(setupRole,false);show(setupDifficulty,false);
    show(setupLeagues,false);show(setupHelp,false);show(setupStart,false);show(setupLoad,false);
    show(mainText,true);show(clubLogoWindow,true);showPage(0);
}
void trigger(int action){
    if(!actionAllowed(page,action)){
        tell("Эта операция недоступна для выбранной должности.");
        return;
    }
    int id=selectedId();
    std::string text=utf8(getText(inputControl));
    std::string response;
    auto go=[&](int p){showPage(p);};
    if(page==0){
        if(action==0)game().advance(1);
        if(action==1)game().advance(7);
        if(action==2)response=fu::saveCareerSafely(game(),saveFile);
        if(action==3){response=game().load(saveFile);if(response.find("загружена")!=std::string::npos)resetPlayback();}
        if(action==4){go(game().canCoach()?PREPARATION_PAGE:4);return;}
    }else if(page==1){
        if(action==0){
            try{response=game().swapStarter(id,std::stoi(text));}
            catch(...){response="Введите числовой ID игрока, которого убираем из основы.";}
        }
        if(action==1)response=game().autoPickLineup();
        if(action==2){go(8);return;}
        if(action==3){go(7);return;}
        if(action==4)response=game().setCaptain(id,false);
        if(action==5)response=game().setCaptain(id,true);
    }else if(page==2){
        if(action==0)game().changeFormation();
        if(action==1)game().changeTactic();
        if(action==2)game().changePressing();
        if(action==3)game().changeTempo();
        if(action==4)game().changeWidth();
        if(action==5){go(PREPARATION_PAGE);return;}
    }else if(page==3){
        if(action==0)game().changeTraining();
        if(action==1)response=game().cycleTrainingFocus(id);
        if(action==2){go(1);return;}
        if(action==3)game().advance(1);
        if(action==4){
            try{response=game().assignMentor(id,std::stoi(text));}
            catch(...){response="Выберите молодого футболиста и введите ID наставника от 25 лет.";}
        }
    }else if(page==4){
        if(action==0){
            autoPlayMatch=false;
            if(!game().hasLiveMatch())game().startLiveMatch();
            else game().stepLiveMatch(15);
        }
        if(action==1){
            if(!game().hasLiveMatch()&&!game().startLiveMatch())
                response=game().status();
            else{
                autoPlayMatch=!autoPlayMatch;
                lastPlaybackTick=GetTickCount64();
                response=autoPlayMatch?"Автовоспроизведение запущено.":"Матч на паузе.";
            }
        }
        if(action==2){
            autoPlayMatch=false;
            if(game().hasLiveMatch())game().stepLiveMatch(90);
            else game().instantMatch();
        }
        if(action==3)game().changeTactic();
        if(action==4)showPitch=!showPitch;
        if(action==5){
            try{response=game().substitute(std::stoi(text),id);}
            catch(...){response="Введите числовой ID футболиста с поля и выберите запасного слева.";}
        }
    }else if(page==5){
        if(action==0){id=game().myClub().league;lastListIndex=id;}
        if(action==1)lastListIndex=(lastListIndex+1)%int(game().leagues().size());
        if(action==2){historyView=1;go(13);return;}
        if(action==3){historyView=0;go(13);return;}
    }else if(page==6){
        if(action==0){
            const auto* deal=game().transferDeal(id);
            if(deal&&(deal->stage==fu::DealStage::AgentOffer||deal->stage==fu::DealStage::AgentCounter)){
                if(deal->kind==1)response=game().acceptNegotiationTerms(id);
                else{
                    std::istringstream in(text);int wage=0,years=0;
                    if(in>>wage>>years)response=game().proposePlayerContract(id,wage,years);
                    else response="Введите зарплату в неделю и годы контракта: 55000 3";
                }
            }else{
                std::istringstream in(text);
                std::string cmd;in>>cmd;
                if(cmd=="loan"){
                    int fee=0,share=0,days=0;
                    if(in>>fee>>share>>days)response=game().offerLoan(id,fee,share,days);
                    else response="Формат аренды: loan 100000 50 180 (плата, % зарплаты, дни)";
                }else if(cmd=="swap"){
                    int fee=0,exchangeId=-1;
                    if(in>>fee>>exchangeId)response=game().offerStructuredTransfer(id,fee,1,0,0,exchangeId);
                    else response="Формат обмена: swap 5000000 123 (сумма и ID вашего игрока)";
                }else if(cmd=="deal"){
                    int fee=0,count=0,bonus=0,sellOn=0;
                    if(in>>fee>>count>>bonus>>sellOn)
                        response=game().offerStructuredTransfer(id,fee,count,bonus,sellOn);
                    else response="Формат условий: deal 15000000 3 1000000 20";
                }else{
                    try{response=game().transferBid(id,std::stoi(text));}
                    catch(...){response="Введите цену в евро или команду loan / deal / swap.";}
                }
            }
        }
        if(action==1)response=game().scoutPlayer(id);
        if(action==2)response=game().toggleShortlist(id);
        if(action==3){shortlistOnly=!shortlistOnly;response=shortlistOnly?"Показываем только короткий список.":"Показываем всех кандидатов.";}
        if(action==4)response=game().acceptNegotiationTerms(id);
        if(action==5)response=game().cancelNegotiation(id);
    }else if(page==7){
        if(action==0){
            std::istringstream in(text);int wage=0,years=0;
            if(in>>wage>>years)response=game().renewContract(id,wage,years);
            else response="Введите зарплату и срок: 30000 3";
        }
        if(action==1){go(1);return;}
        if(action==2){
            std::istringstream in(text);int clubId=-1,fee=0;
            if(in>>clubId>>fee)response=game().sellPlayer(id,clubId,fee);
            else response="Продажа: ID клуба-покупателя и сумма в евро, например 6 3000000";
        }
        if(action==3){
            try{response=game().setReleaseClause(id,std::stoi(text));}
            catch(...){response="Отступные: введите сумму в евро, например 50000000. Ноль — убрать.";}
        }
    }else if(page==8){
        if(action==0)response=game().talk(id,text);
        if(action==1)response=game().talk(id,"Молодец! Я ценю твою работу.");
        if(action==2)response=game().talk(id,"Как дела в семье? Давай поможем с переездом и адаптацией.");
        if(action==3)response=game().teamTalk(0);
        if(action==4)response=game().teamTalk(1);
        if(action==5)response=game().teamTalk(2);
    }else if(page==9){
        if(action==0)response=game().speakToFans(text);
        if(action==1)response=game().speakToFans("Спасибо всем за поддержку нашего клуба!");
        if(action==2)response=game().speakToFans("Приглашаю лидеров болельщиков на встречу. Давайте обсудим проблемы и поддержку.");
    }else if(page==10){
        if(action==0)response=game().spendMoney("stadium");
        if(action==1)response=game().spendMoney("training");
        if(action==2)response=game().spendMoney("academy");
        if(action==3)response=game().negotiateSponsor();
        if(action==4)response=game().adjustTickets(+5);
        if(action==5)response=game().adjustTickets(-5);
    }else if(page==11){
        if(action==0)response=game().signYouthProspect(id);
        if(action==1)response=game().discoverYouth();
        if(action==2){
            std::istringstream in(text);int role=0,quality=0;
            if(in>>role>>quality)response=game().hireStaff(role,quality);
            else response="Нанять: введите роль 0–3 и качество 20–100, например 1 80.";
        }
        if(action==3){
            std::istringstream in(text);int young=0,mentor=0;
            if(in>>young>>mentor)response=game().assignMentor(young,mentor);
            else response="Наставник: введите ID молодого и опытного футболиста, например 2 9.";
        }
        if(action==4){
            std::istringstream in(text);int first=0,second=0,kind=0;
            if(in>>first>>second>>kind)response=game().improveRelationship(first,second,kind);
            else response="Отношения: введите ID двух игроков и действие 0, 1 или 2.";
        }
        if(action==5){
            try{response=game().fireStaff(std::stoi(text));}
            catch(...){response="Укажите ID сотрудника для увольнения.";}
        }
    }else if(page==12){if(action==1){go(0);return;}}
    else if(page==13){
        if(action>=0&&action<=4)historyView=action;
    }
    else if(page==14){
        if(action==0)game().toggleLeague(id);
        if(action==1){showSetup();return;}
        if(action==2)response=fu::saveCareerSafely(game(),saveFile);
        if(action==3){response=game().load(saveFile);if(response.find("загружена")!=std::string::npos)resetPlayback();}
        if(action==4){
            bool ok=game().importPlayers("data/real_players.csv");
            response=game().status();
            if(!ok)response+=" Открой новую карьеру или проверь наличие data/real_players.csv.";
        }
    }else if(page==15){
        if(action==0)response=game().applyForJob(id);
        if(action==1)response=game().acceptJobOffer();
        if(action==2)response=game().withdrawApplication();
        if(action==3)response=game().jobMarketText(id);
        if(action==4){textContent(game().helpText());return;}
    }else if(page==PREPARATION_PAGE){
        if(action>=0&&action<5)response=game().applyMatchPlan(static_cast<fu::TacticalPlan>(action));
        if(action==5){go(4);return;}
    }else if(page==WORLD_MARKET_PAGE){
        if(action==1){go(6);return;}
        if(action==2){historyView=0;go(13);return;}
        if(action==3){go(PREPARATION_PAGE);return;}
        if(action==4)response=fu::saveCareerSafely(game(),saveFile);
    }else if(page==SAVES_PAGE){
        if(action==0)response=fu::saveCareerSafely(game(),careerSlotPath(id));
        if(action==1)response=game().load(careerSlotPath(id).string());
        if(action==2)response=fu::loadCareerBackup(game(),careerSlotPath(id));
        if((action==1||action==2)&&response.find("загружена")!=std::string::npos){
            resetPlayback();resetPlayerSearch();
        }
        if(action==3){go(0);return;}
    }
    showPage(page);
    if(!response.empty())tell(response);
}
void drawButton(const DRAWITEMSTRUCT* dis){
    HDC dc=dis->hDC;RECT r=dis->rcItem;
    bool navButton=dis->CtlID>=NAV_START&&dis->CtlID<NAV_START+NAV_COUNT;
    bool primaryButton=(dis->CtlID>=ACTION_START&&dis->CtlID<ACTION_START+6)||(dis->CtlID==SETUP_START);
    COLORREF color=navButton?(page==int(dis->CtlID-NAV_START)?RGB(28,65,117):RGB(16,27,45)):
        (primaryButton?primary:RGB(32,52,81));
    if(dis->itemState&ODS_DISABLED)color=RGB(35,44,60);
    else if(dis->itemState&ODS_SELECTED)color=RGB(40,84,132);
    HBRUSH brush=CreateSolidBrush(color);
    FillRect(dc,&r,brush);DeleteObject(brush);
    wchar_t text[256];GetWindowTextW(dis->hwndItem,text,256);
    SetBkMode(dc,TRANSPARENT);
    SetTextColor(dc,dis->itemState&ODS_DISABLED?muted:white);
    SelectObject(dc,uiFont);
    DrawTextW(dc,text,-1,&r,DT_SINGLELINE|DT_CENTER|DT_VCENTER|DT_END_ELLIPSIS);
    // Focus on an old nav button must not look like a second selected page.
    if(!navButton&&(dis->itemState&ODS_FOCUS)){
        RECT focus=r;InflateRect(&focus,-3,-3);DrawFocusRect(dc,&focus);
    }
}
LRESULT CALLBACK windowProc(HWND hwnd,UINT msg,WPARAM w,LPARAM l){
    switch(msg){
    case WM_CREATE:{
        trace("WM_CREATE BEGIN");mainWindow=hwnd;
        titleText=create(L"STATIC",L"",WS_CHILD|WS_VISIBLE|SS_LEFT);
        subtitleText=create(L"STATIC",L"",WS_CHILD|WS_VISIBLE|SS_LEFT);
        SendMessageW(titleText,WM_SETFONT,WPARAM(titleFont),TRUE);
        SendMessageW(subtitleText,WM_SETFONT,WPARAM(smallFont),TRUE);
        statusText=create(L"STATIC",L"",WS_CHILD|WS_VISIBLE|SS_LEFT);
        SendMessageW(statusText,WM_SETFONT,WPARAM(smallFont),TRUE);
        for(int i=0;i<NAV_COUNT;++i)nav[i]=create(L"BUTTON",navLabels[i].c_str(),WS_CHILD|BS_OWNERDRAW,NAV_START+i);
        mainText=create(L"EDIT",L"",WS_CHILD|WS_VSCROLL|ES_LEFT|ES_MULTILINE|ES_READONLY|ES_AUTOVSCROLL,502,WS_EX_CLIENTEDGE);
        SendMessageW(mainText,WM_SETFONT,WPARAM(monoFont),TRUE);
        listControl=create(L"LISTBOX",L"",WS_CHILD|WS_VSCROLL|LBS_NOTIFY|LBS_NOINTEGRALHEIGHT,LIST_ID,WS_EX_CLIENTEDGE);
        SendMessageW(listControl,WM_SETFONT,WPARAM(smallFont),TRUE);
        inputControl=create(L"EDIT",L"",WS_CHILD|ES_AUTOHSCROLL|WS_TABSTOP,503,WS_EX_CLIENTEDGE);
        const wchar_t* filterLabels[]={L"Имя / клуб",L"Позиция",L"Возраст до",L"Цена до, €",L"Сортировка"};
        for(int i=0;i<5;++i){
            searchLabels[i]=create(L"STATIC",filterLabels[i],WS_CHILD|SS_LEFT);
            SendMessageW(searchLabels[i],WM_SETFONT,WPARAM(smallFont),TRUE);
        }
        searchName=create(L"EDIT",L"",WS_CHILD|ES_AUTOHSCROLL|WS_TABSTOP,SEARCH_NAME,WS_EX_CLIENTEDGE);
        searchPosition=create(L"COMBOBOX",L"",WS_CHILD|CBS_DROPDOWNLIST|WS_VSCROLL|WS_TABSTOP,SEARCH_POSITION);
        searchAge=create(L"EDIT",L"50",WS_CHILD|ES_NUMBER|ES_AUTOHSCROLL|WS_TABSTOP,SEARCH_AGE,WS_EX_CLIENTEDGE);
        searchPrice=create(L"EDIT",L"500000000",WS_CHILD|ES_NUMBER|ES_AUTOHSCROLL|WS_TABSTOP,SEARCH_PRICE,WS_EX_CLIENTEDGE);
        searchSort=create(L"COMBOBOX",L"",WS_CHILD|CBS_DROPDOWNLIST|WS_VSCROLL|WS_TABSTOP,SEARCH_SORT);
        searchApply=create(L"BUTTON",L"Найти",WS_CHILD|BS_OWNERDRAW|WS_TABSTOP,SEARCH_APPLY);
        searchReset=create(L"BUTTON",L"Сброс",WS_CHILD|BS_OWNERDRAW|WS_TABSTOP,SEARCH_RESET);
        searchCount=create(L"STATIC",L"",WS_CHILD|SS_LEFT);
        SendMessageW(searchCount,WM_SETFONT,WPARAM(smallFont),TRUE);
        SendMessageW(searchName,EM_LIMITTEXT,120,0);SendMessageW(searchAge,EM_LIMITTEXT,3,0);SendMessageW(searchPrice,EM_LIMITTEXT,10,0);
        fillCombo(searchPosition,{L"Любая",L"GK",L"DL",L"DC",L"DR",L"DM",L"MC",L"AMC",L"ML",L"MR",L"AML",L"AMR",L"ST"},0);
        fillCombo(searchSort,{L"Цена ↑",L"Сила ↓",L"Потенциал ↓",L"Возраст ↑",L"Зарплата ↑",L"Имя А–Я"},0);
        for(int i=0;i<6;++i)actions[i]=create(L"BUTTON",L"",WS_CHILD|BS_OWNERDRAW|WS_TABSTOP,ACTION_START+i);
        pitchWindow=CreateWindowExW(0,L"FU_Pitch",L"",WS_CHILD|WS_CLIPSIBLINGS,0,0,10,10,hwnd,nullptr,appInstance,nullptr);
        clubLogoWindow=CreateWindowExW(0,L"FU_ClubLogo",L"",WS_CHILD|WS_VISIBLE|WS_CLIPSIBLINGS,0,0,10,10,hwnd,nullptr,appInstance,nullptr);
        setupName=create(L"EDIT",L"",WS_CHILD|WS_VISIBLE|ES_AUTOHSCROLL|WS_TABSTOP,610,WS_EX_CLIENTEDGE);
        setupClub=create(L"COMBOBOX",L"",WS_CHILD|WS_VISIBLE|CBS_DROPDOWNLIST|WS_VSCROLL,SETUP_CLUB);
        setupRole=create(L"COMBOBOX",L"",WS_CHILD|WS_VISIBLE|CBS_DROPDOWNLIST|WS_VSCROLL,611);
        setupDifficulty=create(L"COMBOBOX",L"",WS_CHILD|WS_VISIBLE|CBS_DROPDOWNLIST|WS_VSCROLL,612);
        setupLeagues=create(L"LISTBOX",L"",WS_CHILD|WS_VISIBLE|WS_VSCROLL|LBS_MULTIPLESEL|LBS_NOINTEGRALHEIGHT,SETUP_LEAGUES,WS_EX_CLIENTEDGE);
        setupHelp=create(L"STATIC",L"",WS_CHILD|WS_VISIBLE|SS_LEFT);
        setupStart=create(L"BUTTON",L"Создать карьеру",WS_CHILD|WS_VISIBLE|BS_OWNERDRAW|WS_TABSTOP,SETUP_START);
        setupLoad=create(L"BUTTON",L"Загрузить",WS_CHILD|WS_VISIBLE|BS_OWNERDRAW|WS_TABSTOP,SETUP_LOAD);
        SendMessageW(setupLeagues,WM_SETFONT,WPARAM(smallFont),TRUE);
        SetTimer(hwnd,PITCH_TIMER,PITCH_TICK_MS,nullptr);
        trace("WM_CREATE before setup");showSetup();trace("WM_CREATE END");return 0;
    }
    case WM_GETMINMAXINFO:{
        auto* info=reinterpret_cast<MINMAXINFO*>(l);
        info->ptMinTrackSize.x=950;
        info->ptMinTrackSize.y=760;
        return 0;
    }
    case WM_SIZE:
        arrange();
        RedrawWindow(hwnd,nullptr,nullptr,RDW_INVALIDATE|RDW_ERASE|RDW_ALLCHILDREN);
        return 0;
    case WM_TIMER:{
        if(w!=PITCH_TIMER)return 0;
        if(started&&page==4){
            const ULONGLONG now=GetTickCount64();
            if(autoPlayMatch&&now-lastPlaybackTick>=ULONGLONG(matchPlaybackDelay())){
                lastPlaybackTick=now;
                if(game().hasLiveMatch()){
                    game().stepLiveMatch(1);
                    if(!game().hasLiveMatch()){
                        autoPlayMatch=false;
                        showPage(4);
                    }else{
                        textContent(game().matchText());
                        tell(game().status());
                    }
                }else autoPlayMatch=false;
            }
            updatePitchFrame();
            if(showPitch&&pitchWindow&&
               (autoPlayMatch||now-pitchTransitionTick<1200))
                InvalidateRect(pitchWindow,nullptr,FALSE);
        }
        return 0;
    }
    case WM_COMMAND:{
        int id=LOWORD(w), code=HIWORD(w);
        if(id>=NAV_START&&id<NAV_START+NAV_COUNT&&code==BN_CLICKED){
            showPage(id-NAV_START);SetFocus(mainWindow);return 0;
        }
        if(id>=ACTION_START&&id<ACTION_START+6&&code==BN_CLICKED){trigger(id-ACTION_START);return 0;}
        if(id==LIST_ID&&code==LBN_SELCHANGE){lastListIndex=int(SendMessageW(listControl,LB_GETCURSEL,0,0));detailForSelected();if(page==6)updateTransferOfferInput();return 0;}
        if(page==6&&(id==SEARCH_APPLY||id==SEARCH_RESET)&&code==BN_CLICKED){
            const int preservedId=selectedId();
            const std::wstring draft=getText(inputControl);
            if(id==SEARCH_RESET)resetPlayerSearch();
            else if(!readPlayerSearch())return 0;
            showPage(6);
            if(selectedId()==preservedId)SetWindowTextW(inputControl,draft.c_str());
            tell(id==SEARCH_RESET?"Фильтры сброшены. Показаны все доступные кандидаты.":"Поиск обновлён. Поле предложения находится внизу.");
            return 0;
        }
        if(id==SETUP_CLUB&&code==CBN_SELCHANGE){InvalidateRect(clubLogoWindow,nullptr,TRUE);return 0;}
        if(id==SETUP_START&&code==BN_CLICKED){startCareer();return 0;}
        if(id==SETUP_LOAD&&code==BN_CLICKED){
            std::string result=game().load(saveFile);
            if(result.find("загружена")!=std::string::npos){
                resetPlayback();resetPlayerSearch();
                started=true;show(setupName,false);show(setupClub,false);show(setupRole,false);show(setupDifficulty,false);
                show(setupLeagues,false);show(setupHelp,false);show(setupStart,false);show(setupLoad,false);
                show(mainText,true);show(clubLogoWindow,true);showPage(0);
            }tell(result);return 0;
        }
        return 0;
    }
    case WM_DRAWITEM:{auto* dis=reinterpret_cast<DRAWITEMSTRUCT*>(l);if(dis->CtlType==ODT_BUTTON){drawButton(dis);return TRUE;}break;}
    case WM_CTLCOLORSTATIC:{
        HDC dc=HDC(w);SetTextColor(dc,white);SetBkColor(dc,background);SetBkMode(dc,OPAQUE);
        return LRESULT(backgroundBrush);
    }
    case WM_CTLCOLOREDIT:case WM_CTLCOLORLISTBOX:{
        HDC dc=HDC(w);SetTextColor(dc,white);SetBkColor(dc,surface);return LRESULT(inputBrush);
    }
    case WM_ERASEBKGND:{
        RECT rect;GetClientRect(hwnd,&rect);FillRect(HDC(w),&rect,backgroundBrush);
        RECT sidebar={0,0,std::clamp(rect.right/5,165,215),rect.bottom};HBRUSH brush=CreateSolidBrush(RGB(10,17,29));FillRect(HDC(w),&sidebar,brush);DeleteObject(brush);return 1;
    }
    case WM_CLOSE:DestroyWindow(hwnd);return 0;
    case WM_DESTROY:KillTimer(hwnd,PITCH_TIMER);PostQuitMessage(0);return 0;
    }
    return DefWindowProcW(hwnd,msg,w,l);
}
}

int WINAPI wWinMain(HINSTANCE instance,HINSTANCE,LPWSTR,int showCommand){
    SetUnhandledExceptionFilter(crashLog);trace("wWinMain START");
    appInstance=instance;
    SetProcessDPIAware();
    Gdiplus::GdiplusStartupInput gdiplusInput;
    if(Gdiplus::GdiplusStartup(&gdiplusToken,&gdiplusInput,nullptr)!=Gdiplus::Ok)return 1;
    trace("GDI+ STARTED");uiFont=CreateFontW(-18,0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Segoe UI");
    smallFont=CreateFontW(-16,0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Segoe UI");
    titleFont=CreateFontW(-33,0,0,0,FW_BOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,DEFAULT_PITCH,L"Segoe UI");
    monoFont=CreateFontW(-17,0,0,0,FW_NORMAL,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,CLEARTYPE_QUALITY,FIXED_PITCH,L"Consolas");
    backgroundBrush=CreateSolidBrush(background);surfaceBrush=CreateSolidBrush(surface);inputBrush=CreateSolidBrush(surface);
    trace("fonts STARTED");WNDCLASSEXW pitchClass{};pitchClass.cbSize=sizeof(pitchClass);pitchClass.hInstance=instance;pitchClass.lpfnWndProc=pitchProc;
    pitchClass.lpszClassName=L"FU_Pitch";pitchClass.hCursor=LoadCursor(nullptr,IDC_ARROW);RegisterClassExW(&pitchClass);
    WNDCLASSEXW logoClass{};logoClass.cbSize=sizeof(logoClass);logoClass.hInstance=instance;logoClass.lpfnWndProc=logoProc;
    logoClass.lpszClassName=L"FU_ClubLogo";logoClass.hCursor=LoadCursor(nullptr,IDC_ARROW);RegisterClassExW(&logoClass);
    WNDCLASSEXW wc{};wc.cbSize=sizeof(wc);wc.hInstance=instance;wc.lpfnWndProc=windowProc;
    wc.lpszClassName=L"FootballUniverseDesktop";wc.hCursor=LoadCursor(nullptr,IDC_ARROW);wc.hIcon=LoadIcon(nullptr,IDI_APPLICATION);
    wc.hbrBackground=backgroundBrush;RegisterClassExW(&wc);
    trace("classes REGISTERED");HWND window=CreateWindowExW(0,wc.lpszClassName,L"Football Universe 0.14.1 — живая футбольная вселенная",
        WS_OVERLAPPEDWINDOW|WS_CLIPCHILDREN,CW_USEDEFAULT,CW_USEDEFAULT,1240,840,nullptr,nullptr,instance,nullptr);
    if(!window){MessageBoxW(nullptr,L"Не удалось создать окно",L"Ошибка",MB_ICONERROR);return 1;}
    trace("window CREATED");ShowWindow(window,showCommand);trace("window SHOWN");UpdateWindow(window);trace("window UPDATED");
    MSG msg{};while(GetMessageW(&msg,nullptr,0,0)>0){TranslateMessage(&msg);DispatchMessageW(&msg);}
    DeleteObject(uiFont);DeleteObject(titleFont);DeleteObject(monoFont);DeleteObject(smallFont);
    DeleteObject(backgroundBrush);DeleteObject(surfaceBrush);DeleteObject(inputBrush);
    Gdiplus::GdiplusShutdown(gdiplusToken);
    return int(msg.wParam);
}
#endif
